<?php

require_once dirname(__DIR__) . '/core/BaseController.php';
require_once dirname(__DIR__) . '/services/AuditService.php';
require_once dirname(__DIR__) . '/services/NotificationService.php';
require_once dirname(__DIR__) . '/services/OrganizationService.php';

class ScheduleController extends BaseController
{
    private AuditService $audit;
    private NotificationService $notifications;
    private OrganizationService $organizations;

    public function __construct()
    {
        parent::__construct();
        $this->audit = new AuditService($this->pdo);
        $this->notifications = new NotificationService($this->pdo);
        $this->organizations = new OrganizationService($this->pdo);
    }

    public function createSlot(): void
    {
        $this->requireLogin();
        $this->requireProfessional();

        $isAjax = $this->isAjaxRequest();
        $startsAt = $this->parseDateTime((string) $this->request->post('starts_at', ''));
        $endsAt = $this->parseDateTime((string) $this->request->post('ends_at', ''));
        $title = trim((string) $this->request->post('titulo', ''));
        $status = (string) $this->request->post('status', 'livre');

        if (!in_array($status, ['livre', 'bloqueado'], true)) {
            $status = 'livre';
        }

        if (!$this->validFutureRange($startsAt, $endsAt)) {
            $this->respondSlotError($isAjax, 'Informe inicio e fim validos, no futuro.', 422);
            return;
        }

        if ($this->hasOverlap((int) $_SESSION['id'], $startsAt, $endsAt)) {
            $this->respondSlotError($isAjax, 'Já existe horário ou bloqueio nessa faixa.', 409);
            return;
        }

        $organizationId = $this->organizations->currentOrganizationId((int) $_SESSION['id']);
        if (database_table_has_column($this->pdo, 'schedule_slots', 'organization_id')) {
            $stmt = $this->pdo->prepare(
                'INSERT INTO schedule_slots (organization_id, professional_id, starts_at, ends_at, status, titulo) VALUES (?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                $organizationId,
                (int) $_SESSION['id'],
                $startsAt->format('Y-m-d H:i:s'),
                $endsAt->format('Y-m-d H:i:s'),
                $status,
                $title ?: null,
            ]);
        } else {
            $stmt = $this->pdo->prepare(
                'INSERT INTO schedule_slots (professional_id, starts_at, ends_at, status, titulo) VALUES (?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                (int) $_SESSION['id'],
                $startsAt->format('Y-m-d H:i:s'),
                $endsAt->format('Y-m-d H:i:s'),
                $status,
                $title ?: null,
            ]);
        }

        $slotId = (int) $this->pdo->lastInsertId();
        $this->audit->log('schedule.slot_created', 'schedule_slot', $slotId, [
            'starts_at' => $startsAt->format('Y-m-d H:i:s'),
            'ends_at' => $endsAt->format('Y-m-d H:i:s'),
            'status' => $status,
        ]);

        if ($isAjax) {
            $this->response->json(['success' => true, 'slot_id' => $slotId]);
            return;
        }

        $this->response->redirect(app_url('/frontend/agenda.php?sucesso=' . urlencode('Horario criado na agenda.')));
    }

    public function updateSlot(): void
    {
        $this->requireLogin();
        $isAjax = $this->isAjaxRequest();
        $slotId = (int) $this->request->post('slot_id', 0);

        if ($slotId <= 0) {
            $this->respondSlotError($isAjax, 'Dados inválidos do horário.', 400);
            return;
        }

        $slot = $this->slotById($slotId);
        if (!$slot || !$this->canManageSlot($slot)) {
            $this->respondSlotError($isAjax, 'Horário indisponível para seu perfil.', 403);
            return;
        }

        $startsRaw = (string) $this->request->post('starts_at', '');
        $endsRaw = (string) $this->request->post('ends_at', '');
        if ($startsRaw !== '' || $endsRaw !== '') {
            $this->updateSlotRange($slot, $isAjax);
            return;
        }

        $status = (string) $this->request->post('status', '');
        if (!in_array($status, ['livre', 'bloqueado'], true)) {
            $this->respondSlotError($isAjax, 'Status inválido do horário.', 400);
            return;
        }

        if ($this->hasActiveAppointment($slotId)) {
            $this->respondSlotError($isAjax, 'Horario com atendimento ativo nao pode ser liberado ou bloqueado manualmente.', 409);
            return;
        }

        $stmt = $this->pdo->prepare('UPDATE schedule_slots SET status = ? WHERE id = ?');
        $stmt->execute([$status, $slotId]);
        $this->audit->log('schedule.slot_updated', 'schedule_slot', $slotId, ['status' => $status]);

        if ($isAjax) {
            $this->response->json(['success' => true, 'slot_id' => $slotId]);
            return;
        }

        $this->response->redirect(app_url('/frontend/agenda.php?sucesso=' . urlencode('Horario atualizado.')));
    }

    public function book(): void
    {
        $this->requireLogin();

        if (($_SESSION['tipo'] ?? '') !== 'cliente') {
            $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode('Apenas clientes podem agendar atendimentos.')));
        }

        $slotId = (int) $this->request->post('slot_id', 0);
        $caseId = $this->request->post('case_id', '');
        $caseId = $caseId === '' ? null : (int) $caseId;
        $subject = trim((string) $this->request->post('assunto', ''));
        $notes = trim((string) $this->request->post('observacoes', ''));

        if ($slotId <= 0 || $subject === '') {
            $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode('Escolha um horário e informe o assunto.')));
        }

        $slot = $this->slotById($slotId);
        if (
            !$slot
            || (string) $slot['status'] !== 'livre'
            || new DateTimeImmutable((string) $slot['starts_at']) < new DateTimeImmutable()
        ) {
            $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode('Este horário não está mais livre.')));
        }

        if ((string) $slot['tipo'] !== 'advogado' || (int) ($slot['oab_verificado'] ?? 0) !== 1) {
            $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode('Profissional inválido para agenda.')));
        }

        if ($caseId !== null && !$this->caseBelongsToClient($caseId, (int) $_SESSION['id'])) {
            $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode('Caso inválido para seu usuário.')));
        }

        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare("UPDATE schedule_slots SET status = 'ocupado' WHERE id = ? AND status = 'livre'");
            $stmt->execute([$slotId]);

            if ($stmt->rowCount() === 0) {
                $this->pdo->rollBack();
                $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode('Este horário acabou de ser reservado.')));
            }

            $organizationId = $this->organizations->currentOrganizationId((int) $_SESSION['id'])
                ?: (int) ($slot['organization_id'] ?? 0)
                ?: null;
            if (database_table_has_column($this->pdo, 'appointments', 'organization_id')) {
                $stmt = $this->pdo->prepare(
                    'INSERT INTO appointments (organization_id, slot_id, client_id, case_id, assunto, observacoes) VALUES (?, ?, ?, ?, ?, ?)'
                );
                $stmt->execute([$organizationId, $slotId, (int) $_SESSION['id'], $caseId, $subject, $notes ?: null]);
            } else {
                $stmt = $this->pdo->prepare(
                    'INSERT INTO appointments (slot_id, client_id, case_id, assunto, observacoes) VALUES (?, ?, ?, ?, ?)'
                );
                $stmt->execute([$slotId, (int) $_SESSION['id'], $caseId, $subject, $notes ?: null]);
            }
            $appointmentId = (int) $this->pdo->lastInsertId();
            $this->pdo->commit();
        } catch (Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }

        $this->notifications->notify((int) $slot['professional_id'], 'Novo agendamento em sua agenda: ' . $subject);
        $this->notifications->notify((int) $_SESSION['id'], 'Agendamento confirmado com ' . (string) $slot['professional_name'] . '.');
        $this->notifications->notifyMany($this->notifications->activeAdmins(), 'Novo agendamento criado: ' . $subject);
        $this->audit->log('schedule.appointment_booked', 'appointment', $appointmentId, [
            'slot_id' => $slotId,
            'professional_id' => (int) $slot['professional_id'],
            'case_id' => $caseId,
        ]);

        $this->response->redirect(app_url('/frontend/agenda.php?sucesso=' . urlencode('Atendimento agendado.')));
    }

    public function updateAppointment(): void
    {
        $this->requireLogin();

        $appointmentId = (int) $this->request->post('appointment_id', 0);
        $status = (string) $this->request->post('status', '');

        if ($appointmentId <= 0 || !in_array($status, ['cancelado', 'concluido'], true)) {
            $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode('Dados inválidos do agendamento.')));
        }

        $appointment = $this->appointmentById($appointmentId);
        if (!$appointment || !$this->canManageAppointment($appointment, $status)) {
            $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode('Agendamento indisponível para seu perfil.')));
        }

        if ((string) ($appointment['status'] ?? '') !== 'agendado') {
            $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode('Apenas agendamentos ativos podem ser atualizados.')));
        }

        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare('UPDATE appointments SET status = ? WHERE id = ?');
            $stmt->execute([$status, $appointmentId]);

            if ($status === 'cancelado') {
                $stmt = $this->pdo->prepare("UPDATE schedule_slots SET status = 'livre' WHERE id = ? AND starts_at > NOW()");
                $stmt->execute([(int) $appointment['slot_id']]);
            }

            $this->pdo->commit();
        } catch (Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }

        $this->notifications->notifyMany(
            [(int) $appointment['client_id'], (int) $appointment['professional_id']],
            'Agendamento "' . (string) $appointment['assunto'] . '" atualizado para: ' . $status
        );
        $this->audit->log('schedule.appointment_updated', 'appointment', $appointmentId, ['status' => $status]);

        $this->response->redirect(app_url('/frontend/agenda.php?sucesso=' . urlencode('Agendamento atualizado.')));
    }

    public function calendarData(): void
    {
        $this->startSession();

        if (empty($_SESSION['logado'])) {
            $this->response->json(['error' => 'auth_required'], 401);
            return;
        }

        $start = (string) $this->request->get('start', '');
        $end = (string) $this->request->get('end', '');
        $professionalId = (int) $this->request->get('professional_id', 0);
        $roleFilter = (string) $this->request->get('perfil', '');
        $userType = (string) ($_SESSION['tipo'] ?? '');
        $userId = (int) ($_SESSION['id'] ?? 0);

        [$startStr, $endStr] = $this->calendarRange($start, $end);
        if ($startStr === null || $endStr === null) {
            $this->response->json(['error' => 'invalid_range'], 400);
            return;
        }

        [$slotWhere, $slotParams] = $this->slotCalendarFilter($userType, $userId, $startStr, $endStr, $professionalId, $roleFilter);
        if (!$slotWhere) {
            $this->response->json(['error' => 'forbidden'], 403);
            return;
        }

        $slots = $this->fetchAll(
            'SELECT s.id, s.professional_id, s.starts_at, s.ends_at, s.status, s.titulo,
                    u.nome AS professional_name, u.tipo
             FROM schedule_slots s
             INNER JOIN users u ON u.id = s.professional_id
             WHERE ' . implode(' AND ', $slotWhere) . '
             ORDER BY s.starts_at ASC',
            $slotParams
        );

        [$appointmentWhere, $appointmentParams] = $this->appointmentCalendarFilter($userType, $userId, $startStr, $endStr, $professionalId, $roleFilter);
        $appointments = $appointmentWhere ? $this->fetchAll(
            'SELECT a.id, a.slot_id, a.client_id, a.case_id, a.assunto, a.status,
                    s.starts_at, s.ends_at, s.professional_id,
                    pro.nome AS professional_name, pro.tipo, cli.nome AS client_name
             FROM appointments a
             INNER JOIN schedule_slots s ON s.id = a.slot_id
             INNER JOIN users pro ON pro.id = s.professional_id
             LEFT JOIN users cli ON cli.id = a.client_id
             WHERE ' . implode(' AND ', $appointmentWhere) . '
             ORDER BY s.starts_at ASC',
            $appointmentParams
        ) : [];

        $this->response->json(['slots' => $slots, 'appointments' => $appointments]);
    }

    private function updateSlotRange(array $slot, bool $isAjax): void
    {
        $slotId = (int) $slot['id'];
        if ($this->hasActiveAppointment($slotId)) {
            $this->respondSlotError($isAjax, 'Horario com atendimento ativo nao pode ser editado.', 409);
            return;
        }

        $startsAt = $this->parseDateTime((string) $this->request->post('starts_at', ''));
        $endsAt = $this->parseDateTime((string) $this->request->post('ends_at', ''));
        $title = trim((string) $this->request->post('titulo', ''));
        $status = (string) $this->request->post('status', (string) ($slot['status'] ?? 'livre'));

        if (!in_array($status, ['livre', 'bloqueado'], true)) {
            $status = (string) ($slot['status'] ?? 'livre');
        }

        if (!$this->validFutureRange($startsAt, $endsAt)) {
            $this->respondSlotError($isAjax, 'Informe inicio e fim validos, no futuro.', 422);
            return;
        }

        if ($this->hasOverlap((int) $slot['professional_id'], $startsAt, $endsAt, $slotId)) {
            $this->respondSlotError($isAjax, 'Já existe horário ou bloqueio nessa faixa.', 409);
            return;
        }

        $stmt = $this->pdo->prepare('UPDATE schedule_slots SET starts_at = ?, ends_at = ?, titulo = ?, status = ? WHERE id = ?');
        $stmt->execute([
            $startsAt->format('Y-m-d H:i:s'),
            $endsAt->format('Y-m-d H:i:s'),
            $title ?: null,
            $status,
            $slotId,
        ]);

        $this->audit->log('schedule.slot_updated', 'schedule_slot', $slotId, [
            'starts_at' => $startsAt->format('Y-m-d H:i:s'),
            'ends_at' => $endsAt->format('Y-m-d H:i:s'),
            'status' => $status,
        ]);

        if ($isAjax) {
            $this->response->json(['success' => true, 'slot_id' => $slotId]);
            return;
        }

        $this->response->redirect(app_url('/frontend/agenda.php?sucesso=' . urlencode('Horario atualizado.')));
    }

    private function fetchAll(string $sql, array $params = []): array
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    private function requireLogin(): void
    {
        $this->startSession();

        if (empty($_SESSION['logado'])) {
            $this->response->redirect(app_url('/frontend/login.html?erro=' . urlencode('Faça login para continuar.')));
        }
    }

    private function requireProfessional(): void
    {
        if (($_SESSION['tipo'] ?? '') !== 'advogado') {
            $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode('Apenas profissionais gerenciam horários.')));
        }

        $stmt = $this->pdo->prepare("SELECT oab_verificado FROM users WHERE id = ? AND status = 'ativo'");
        $stmt->execute([(int) ($_SESSION['id'] ?? 0)]);
        $isVerified = (int) ($stmt->fetchColumn() ?: 0) === 1;

        if (!$isVerified) {
            $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode('Sua OAB precisa ser validada pela administração para abrir horários.')));
        }
    }

    private function parseDateTime(string $value): ?DateTimeImmutable
    {
        if (trim($value) === '') {
            return null;
        }

        try {
            return new DateTimeImmutable(str_replace('T', ' ', $value));
        } catch (Throwable) {
            return null;
        }
    }

    private function validFutureRange(?DateTimeImmutable $startsAt, ?DateTimeImmutable $endsAt): bool
    {
        if (!$startsAt || !$endsAt || $endsAt <= $startsAt) {
            return false;
        }

        return $startsAt >= new DateTimeImmutable('-5 minutes');
    }

    private function hasOverlap(int $professionalId, DateTimeImmutable $startsAt, DateTimeImmutable $endsAt, ?int $excludeSlotId = null): bool
    {
        $sql = 'SELECT COUNT(*) FROM schedule_slots
                WHERE professional_id = ?
                  AND starts_at < ?
                  AND ends_at > ?';
        $params = [$professionalId, $endsAt->format('Y-m-d H:i:s'), $startsAt->format('Y-m-d H:i:s')];

        if ($excludeSlotId !== null) {
            $sql .= ' AND id <> ?';
            $params[] = $excludeSlotId;
        }

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn() > 0;
    }

    private function isAjaxRequest(): bool
    {
        return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
            || (isset($_SERVER['HTTP_ACCEPT']) && strpos((string) $_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
            || ((string) $this->request->header('X-Requested-With') === 'XMLHttpRequest');
    }

    private function respondSlotError(bool $isAjax, string $message, int $statusCode = 400): void
    {
        if ($isAjax) {
            $this->response->json(['success' => false, 'error' => $message], $statusCode);
            return;
        }

        $this->response->redirect(app_url('/frontend/agenda.php?erro=' . urlencode($message)));
    }

    private function slotById(int $slotId): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT s.*, u.nome AS professional_name, u.tipo, u.oab_verificado
             FROM schedule_slots s
             INNER JOIN users u ON u.id = s.professional_id
             WHERE s.id = ?'
        );
        $stmt->execute([$slotId]);
        $slot = $stmt->fetch();

        return $slot ?: null;
    }

    private function appointmentById(int $appointmentId): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT a.*, s.professional_id, s.starts_at, s.ends_at
             FROM appointments a
             INNER JOIN schedule_slots s ON s.id = a.slot_id
             WHERE a.id = ?'
        );
        $stmt->execute([$appointmentId]);
        $appointment = $stmt->fetch();

        return $appointment ?: null;
    }

    private function hasActiveAppointment(int $slotId): bool
    {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM appointments WHERE slot_id = ? AND status = 'agendado'");
        $stmt->execute([$slotId]);
        return (int) $stmt->fetchColumn() > 0;
    }

    private function caseBelongsToClient(int $caseId, int $clientId): bool
    {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM cases WHERE id = ? AND cliente_id = ? AND status <> 'finalizado'");
        $stmt->execute([$caseId, $clientId]);
        return (int) $stmt->fetchColumn() > 0;
    }

    private function canManageSlot(array $slot): bool
    {
        $type = (string) ($_SESSION['tipo'] ?? '');
        $userId = (int) ($_SESSION['id'] ?? 0);
        return $type === 'admin' || (int) $slot['professional_id'] === $userId;
    }

    private function canManageAppointment(array $appointment, string $newStatus): bool
    {
        $type = (string) ($_SESSION['tipo'] ?? '');
        $userId = (int) ($_SESSION['id'] ?? 0);

        if ($type === 'admin') {
            return true;
        }

        if ($type === 'cliente') {
            return (int) $appointment['client_id'] === $userId && $newStatus === 'cancelado';
        }

        if ($type === 'advogado') {
            return (int) $appointment['professional_id'] === $userId;
        }

        return false;
    }

    private function calendarRange(string $start, string $end): array
    {
        if ($start === '' || $end === '') {
            $now = new DateTimeImmutable();
            $startDt = $now->modify('first day of this month');
            $endDt = $now->modify('last day of this month');
        } else {
            $startDt = DateTimeImmutable::createFromFormat('Y-m-d', $start);
            $endDt = DateTimeImmutable::createFromFormat('Y-m-d', $end);
        }

        if (!$startDt || !$endDt) {
            return [null, null];
        }

        return [
            $startDt->setTime(0, 0, 0)->format('Y-m-d H:i:s'),
            $endDt->setTime(23, 59, 59)->format('Y-m-d H:i:s'),
        ];
    }

    private function slotCalendarFilter(string $userType, int $userId, string $startStr, string $endStr, int $professionalId, string $roleFilter): array
    {
        $where = ['s.starts_at >= ?', 's.ends_at <= ?'];
        $params = [$startStr, $endStr];

        if ($userType === 'cliente') {
            $where[] = "s.status = 'livre'";
            $where[] = "u.status = 'ativo'";
            $where[] = "u.tipo = 'advogado'";
            $where[] = 'u.oab_verificado = TRUE';
        } elseif ($userType === 'admin') {
            // Admin keeps the base range filter.
        } elseif ($userType === 'advogado') {
            $where[] = 's.professional_id = ?';
            $params[] = $userId;
        } else {
            return [[], []];
        }

        if (in_array($userType, ['cliente', 'admin'], true) && $professionalId > 0) {
            $where[] = 's.professional_id = ?';
            $params[] = $professionalId;
        }

        if (in_array($userType, ['cliente', 'admin'], true) && $roleFilter === 'advogado') {
            $where[] = 'u.tipo = ?';
            $params[] = $roleFilter;
        }

        return [$where, $params];
    }

    private function appointmentCalendarFilter(string $userType, int $userId, string $startStr, string $endStr, int $professionalId, string $roleFilter): array
    {
        $where = ['s.starts_at >= ?', 's.ends_at <= ?'];
        $params = [$startStr, $endStr];

        if ($userType === 'cliente') {
            $where[] = 'a.client_id = ?';
            $params[] = $userId;
        } elseif ($userType === 'admin') {
            // Admin keeps the base range filter.
        } elseif ($userType === 'advogado') {
            $where[] = 's.professional_id = ?';
            $params[] = $userId;
        } else {
            return [[], []];
        }

        if (in_array($userType, ['cliente', 'admin'], true) && $professionalId > 0) {
            $where[] = 's.professional_id = ?';
            $params[] = $professionalId;
        }

        if (in_array($userType, ['cliente', 'admin'], true) && $roleFilter === 'advogado') {
            $where[] = 'pro.tipo = ?';
            $params[] = $roleFilter;
        }

        return [$where, $params];
    }
}
