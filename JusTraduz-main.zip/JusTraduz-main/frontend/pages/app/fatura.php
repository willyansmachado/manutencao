<?php
require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_login();
require_once FRONTEND_APP_PATH . '/support/billing_documents.php';
require_once FRONTEND_APP_PATH . '/support/simple_pdf.php';

$eventId = (int) ($_GET['id'] ?? 0);
$event = $eventId > 0 ? billing_document_event($pdo, $eventId, current_user_id()) : null;
if (!$event) {
    http_response_code(404);
    echo 'Fatura não encontrada.';
    exit;
}

[$statusLabel] = billing_status_label((string) ($event['status'] ?? 'pending'));
$payload = billing_payload($event);
$date = (string) (($event['created_at'] ?? '') ?: ($event['processed_at'] ?? ''));
$periodStart = (string) (($event['current_period_start'] ?? '') ?: ($payload['period_start'] ?? $date));
$periodEnd = (string) (($event['current_period_end'] ?? '') ?: ($payload['period_end'] ?? ''));
$planName = (string) (($event['plan_name'] ?? '') ?: 'Plano JusTraduz');
$method = billing_method_label($event);
$cycle = billing_cycle_label($event);
$amountCents = (int) ($event['amount_cents'] ?? 0);
$documentNumber = billing_document_number('JT-FAT', (int) $event['id']);
$providerPaymentId = (string) ($event['provider_event_id'] ?? '');
$downloadMode = (string) ($_GET['download'] ?? '') === '1';

if ($downloadMode) {
    $clientLines = array_filter([
        (string) ($event['user_name'] ?? current_user_name()),
        (string) ($event['user_email'] ?? ''),
        !empty($event['user_cpf']) ? 'CPF ' . (string) $event['user_cpf'] : '',
        (string) ($event['user_phone'] ?? ''),
    ]);

    simple_pdf_download('fatura-' . $documentNumber . '.pdf', [
        'title' => 'Fatura',
        'number' => $documentNumber,
        'meta' => [
            'Emissão' => billing_date($date),
            'Status' => $statusLabel,
        ],
        'left_title' => 'Emitido por',
        'left_lines' => ['JusTraduz', 'Plataforma jurídica digital', 'Brasil'],
        'right_title' => 'Cliente',
        'right_lines' => $clientLines,
        'summary' => billing_money($amountCents) . ' ' . ($statusLabel === 'Pago' ? 'pago' : 'a vencer') . ' em ' . billing_date($date),
        'headers' => ['Descrição', 'Método', 'Valor'],
        'columns' => [300, 105, 95],
        'rows' => [[
            $planName . ' - ' . $cycle . ' | ' . billing_date($periodStart) . ($periodEnd !== '' ? ' - ' . billing_date($periodEnd) : ''),
            $method,
            billing_money($amountCents),
        ]],
        'totals' => [
            'Subtotal' => billing_money($amountCents),
            'Total' => billing_money($amountCents),
            'Valor devido' => $statusLabel === 'Pago' ? 'R$ 0,00' : billing_money($amountCents),
        ],
        'footer' => array_filter([
            $providerPaymentId !== '' ? 'Pagamento Asaas: ' . $providerPaymentId : '',
            'Documento interno gerado a partir dos eventos de cobrança registrados no JusTraduz.',
        ]),
    ]);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta name="robots" content="noindex, nofollow">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Fatura <?= e($documentNumber) ?> | JusTraduz</title>
  <style>
    :root {
      color: #172033;
      background: #f4f6f9;
      font-family: Manrope, "Segoe UI", Roboto, Arial, sans-serif;
    }

    * {
      box-sizing: border-box;
    }

    html,
    body {
      max-width: 100%;
      overflow-x: hidden;
    }

    body {
      margin: 0;
      background: #f4f6f9;
      color: #172033;
    }

    .doc-actions {
      position: sticky;
      top: 0;
      z-index: 2;
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 10px;
      padding: 14px;
      background: rgba(244, 246, 249, .92);
      backdrop-filter: blur(10px);
      border-bottom: 1px solid #d9e1ea;
    }

    .doc-actions a,
    .doc-actions button {
      min-height: 40px;
      padding: 0 16px;
      border: 1px solid #118a7e;
      border-radius: 8px;
      background: #118a7e;
      color: #fff;
      font-weight: 800;
      text-decoration: none;
      cursor: pointer;
      text-align: center;
    }

    .doc-actions a {
      display: inline-flex;
      align-items: center;
      background: #fff;
      color: #0f766d;
    }

    .document {
      width: min(920px, calc(100% - 32px));
      min-height: 1180px;
      margin: 24px auto;
      padding: 56px;
      background: #fff;
      border: 1px solid #d9e1ea;
      border-radius: 8px;
      box-shadow: 0 18px 52px rgba(23, 32, 51, .10);
    }

    .doc-head,
    .doc-two-col,
    .doc-row,
    .doc-total-row {
      display: flex;
      justify-content: space-between;
      gap: 30px;
    }

    .doc-head {
      align-items: flex-start;
      margin-bottom: 48px;
      padding-bottom: 24px;
      border-bottom: 3px solid #118a7e;
    }

    h1 {
      margin: 0;
      font-size: 30px;
      color: #172033;
    }

    h2 {
      margin: 0 0 12px;
      font-size: 16px;
      color: #172033;
    }

    .brand {
      font-size: 34px;
      font-weight: 900;
      letter-spacing: 0;
      color: #118a7e;
    }

    .doc-meta,
    .doc-party,
    .doc-summary {
      line-height: 1.55;
      overflow-wrap: anywhere;
    }

    .doc-meta strong,
    .doc-party strong {
      display: inline-block;
      min-width: 128px;
    }

    .doc-two-col {
      margin-bottom: 54px;
    }

    .doc-party {
      width: 48%;
      padding: 18px;
      border: 1px solid #d9e1ea;
      border-radius: 8px;
      background: #f8fafc;
    }

    .doc-summary {
      margin: 0 0 34px;
      padding: 18px;
      border: 1px solid rgba(17, 138, 126, .22);
      border-radius: 8px;
      background: #e8f6f4;
      color: #0f766d;
      font-size: 22px;
      font-weight: 800;
    }

    .doc-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 28px;
    }

    .doc-table th {
      border-bottom: 1px solid #172033;
      padding: 10px 0;
      font-size: 12px;
      text-align: left;
      color: #657286;
      text-transform: uppercase;
    }

    .doc-table td {
      padding: 14px 0;
      border-bottom: 1px solid #edf1f5;
      vertical-align: top;
    }

    .doc-table th:last-child,
    .doc-table td:last-child {
      text-align: right;
    }

    .doc-totals {
      width: min(420px, 100%);
      margin-left: auto;
    }

    .doc-total-row {
      padding: 8px 0;
      border-bottom: 1px solid #d9e1ea;
    }

    .doc-total-row:last-child {
      border-bottom: 0;
      color: #0f766d;
      font-weight: 900;
    }

    .doc-foot {
      margin-top: 72px;
      color: #657286;
      font-size: 12px;
      line-height: 1.6;
    }

    @media (max-width: 720px) {
      .doc-actions {
        align-items: stretch;
        padding: 10px;
      }

      .doc-actions a,
      .doc-actions button {
        flex: 1 1 170px;
        justify-content: center;
        min-height: 44px;
      }

      .document {
        width: 100%;
        min-height: auto;
        margin: 0;
        padding: 28px 18px;
        border: 0;
        border-radius: 0;
      }

      .doc-head,
      .doc-two-col,
      .doc-row,
      .doc-total-row {
        flex-direction: column;
        gap: 10px;
      }

      .doc-party {
        width: 100%;
      }

      .brand {
        font-size: 28px;
      }

      h1 {
        font-size: 24px;
      }

      .doc-summary {
        font-size: 18px;
      }

      .doc-table {
        display: block;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        white-space: nowrap;
      }

      .doc-table th,
      .doc-table td {
        min-width: 120px;
      }

      .doc-table th:first-child,
      .doc-table td:first-child {
        min-width: 240px;
        white-space: normal;
      }
    }

    @media print {
      body {
        background: #fff;
      }

      .doc-actions {
        display: none;
      }

      .document {
        width: 100%;
        min-height: 0;
        margin: 0;
        padding: 34px;
        border: 0;
        box-shadow: none;
      }
    }
  </style>
</head>
<body>
  <?php if (!$downloadMode): ?>
    <div class="doc-actions">
      <a href="<?= e(app_url('/frontend/perfil.php?tab=faturamento')) ?>">Voltar</a>
      <a href="<?= e(app_url('/frontend/fatura.php?id=' . $eventId . '&download=1')) ?>">Baixar PDF</a>
      <button type="button" onclick="window.print()">Imprimir / salvar PDF</button>
    </div>
  <?php endif; ?>

  <main class="document">
    <header class="doc-head">
      <div>
        <h1>Fatura</h1>
        <p class="doc-meta">
          <strong>Número</strong> <?= e($documentNumber) ?><br>
          <strong>Emissão</strong> <?= e(billing_date($date)) ?><br>
          <strong>Status</strong> <?= e($statusLabel) ?>
        </p>
      </div>
      <div class="brand">JusTraduz</div>
    </header>

    <section class="doc-two-col">
      <div class="doc-party">
        <h2>Emitido por</h2>
        <p>JusTraduz<br>Plataforma jurídica digital<br>Brasil</p>
      </div>
      <div class="doc-party">
        <h2>Cliente</h2>
        <p>
          <?= e((string) ($event['user_name'] ?? current_user_name())) ?><br>
          <?= e((string) ($event['user_email'] ?? '')) ?><br>
          <?php if (!empty($event['user_cpf'])): ?>CPF <?= e((string) $event['user_cpf']) ?><br><?php endif; ?>
          <?php if (!empty($event['user_phone'])): ?><?= e((string) $event['user_phone']) ?><?php endif; ?>
        </p>
      </div>
    </section>

    <p class="doc-summary"><?= e(billing_money($amountCents)) ?> <?= $statusLabel === 'Pago' ? 'pago' : 'a vencer' ?> em <?= e(billing_date($date)) ?></p>

    <table class="doc-table">
      <thead>
        <tr>
          <th>Descrição</th>
          <th>Método</th>
          <th>Valor</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <?= e($planName) ?> - <?= e($cycle) ?><br>
            <small><?= e(billing_date($periodStart)) ?><?= $periodEnd !== '' ? ' - ' . e(billing_date($periodEnd)) : '' ?></small>
          </td>
          <td><?= e($method) ?></td>
          <td><?= e(billing_money($amountCents)) ?></td>
        </tr>
      </tbody>
    </table>

    <section class="doc-totals">
      <div class="doc-total-row"><span>Subtotal</span><span><?= e(billing_money($amountCents)) ?></span></div>
      <div class="doc-total-row"><span>Total</span><span><?= e(billing_money($amountCents)) ?></span></div>
      <div class="doc-total-row"><span>Valor devido</span><span><?= $statusLabel === 'Pago' ? 'R$ 0,00' : e(billing_money($amountCents)) ?></span></div>
    </section>

    <footer class="doc-foot">
      <?php if ($providerPaymentId !== ''): ?>Pagamento Asaas: <?= e($providerPaymentId) ?><br><?php endif; ?>
      Documento interno gerado a partir dos eventos de cobrança registrados no JusTraduz.
    </footer>
  </main>
</body>
</html>
